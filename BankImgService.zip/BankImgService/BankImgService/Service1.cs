﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;

namespace BankImgService
{
    public partial class Service1 : ServiceBase
    {
        public Service1()
        {
            InitializeComponent();
        }
        private System.Timers.Timer myTimer;//timer
        string path_log="";
        string srcPath = "";
        string tagPath = "";
        double IntervalTime =86400000 ;
        /// <summary>
        /// 重写服务OnStart方法
        /// </summary>
        /// <param name="args"></param>
        protected override void OnStart(string[] args)
        {
             path_log = ConfigurationManager.AppSettings["log"].ToString();
             srcPath = ConfigurationManager.AppSettings["srcPath"].ToString();
             tagPath = ConfigurationManager.AppSettings["tagPath"].ToString();
             IntervalTime = Convert.ToDouble(ConfigurationManager.AppSettings["IntervalTime"].ToString());
            using (FileStream stream = new FileStream(path_log, FileMode.Append))
            using (StreamWriter writer = new StreamWriter(stream))
            {
                writer.WriteLine($"{DateTime.Now},服务启动！");
            }
            myTimer = new System.Timers.Timer();
            myTimer.Interval = IntervalTime; //设置计时器事件间隔执行时间
            myTimer.Elapsed += MyTimer_Elapsed;
            myTimer.Enabled = true;

        }

        private void MyTimer_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
        {
            try
            {
                DoWork();
            }
            catch (Exception ex)
            {

            }
        }

        /// <summary>
        /// 重写服务OnStop方法
        /// </summary>
        protected override void OnStop()
        {
            using (FileStream stream = new FileStream(path_log, FileMode.Append))
            using (StreamWriter writer = new StreamWriter(stream))
            {
                writer.WriteLine($"{DateTime.Now},服务停止！");
            }
        }


        //逻辑代码
        void DoWork()
        {
            using (FileStream stream = new FileStream(path_log, FileMode.Append))
            using (StreamWriter writer = new StreamWriter(stream))
            {

                string path = srcPath;
                if (!System.IO.Directory.Exists(path))
                {
                    // 目录不存在，建立目录
                    System.IO.Directory.CreateDirectory(path);
                }
                //创建备份文件夹，按时间命名  
                String bakDir = tagPath + "\\" + DateTime.Now.ToString("yyyy-MM-dd");

                CopyDir(path, bakDir);
                writer.WriteLine($"{DateTime.Now},备份完成");

            }
        }

        private static void CopyDir(string srcPath, string aimPath)
        {

            try

            {

                // 检查目标目录是否以目录分割字符结束如果不是则添加

                if (aimPath[aimPath.Length - 1] != System.IO.Path.DirectorySeparatorChar)

                {

                    aimPath += System.IO.Path.DirectorySeparatorChar;

                }

                // 判断目标目录是否存在如果不存在则新建

                if (!System.IO.Directory.Exists(aimPath))
                {

                    System.IO.Directory.CreateDirectory(aimPath);

                }

                // 得到源目录的文件列表，该里面是包含文件以及目录路径的一个数组

                // 如果你指向copy目标文件下面的文件而不包含目录请使用下面的方法

                // string[] fileList = Directory.GetFiles（srcPath）；

                string[] fileList = System.IO.Directory.GetFileSystemEntries(srcPath);

                // 遍历所有的文件和目录

                foreach (string file in fileList)

                {

                    // 先当作目录处理如果存在这个目录就递归Copy该目录下面的文件

                    if (System.IO.Directory.Exists(file))

                    {

                        CopyDir(file, aimPath + System.IO.Path.GetFileName(file));

                    }

                    // 否则直接Copy文件

                    else

                    {

                        System.IO.File.Copy(file, aimPath + System.IO.Path.GetFileName(file), true);

                    }

                }

            }

            catch (Exception e)
            {

                throw;

            }

        }
    }
}
